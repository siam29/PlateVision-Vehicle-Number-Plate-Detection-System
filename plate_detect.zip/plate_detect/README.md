# PlateVision — Vehicle Number Plate Detection System

A full-stack web application for detecting vehicle number plates in images and videos,
with user authentication, result storage, and detection history.

---

## 🗂 Project Structure

```
plate_detect/
├── app.py                        # Flask backend (routes, auth, DB)
├── requirements.txt              # Python dependencies
├── utils/
│   ├── __init__.py
│   └── detector.py               # OpenCV plate detection logic
├── templates/
│   ├── auth.html                 # Login / Sign Up page
│   └── dashboard.html            # Main dashboard (image + video detection)
└── static/
    ├── uploads/
    │   ├── images/               # Uploaded images stored here
    │   └── videos/               # Uploaded videos stored here
    └── results/
        ├── images/               # Annotated result images saved here
        └── videos/               # Annotated result videos saved here
```

---

## ⚙️ Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the app
```bash
python app.py
```

### 3. Open in browser
```
http://localhost:5000
```

---

## 🚀 Features

- **Authentication** — Secure signup/login with bcrypt password hashing
- **Image Detection** — Upload any image; plates highlighted with green border
- **Video Detection** — Upload video; every frame is processed, plates marked with green borders
- **Auto-save Results** — All annotated files saved in `static/results/`
- **Detection History** — Full log of every scan per user
- **Dashboard Stats** — See total scans, image scans, video scans at a glance

---

## 🧠 Detection Engine

Uses OpenCV's Haar Cascade classifiers:
- `haarcascade_russian_plate_number.xml`
- `haarcascade_license_plate_rus_16stages.xml`

Both cascades run in parallel; results are deduplicated with IoU-based overlap removal.
Each detected plate gets:
- A **green bounding box** (3px thick)
- A **"NUMBER PLATE"** label with a green background

---

## 📁 Output Files

| Input Type | Saved To |
|---|---|
| Uploaded image | `static/uploads/images/` |
| Annotated image | `static/results/images/` |
| Uploaded video | `static/uploads/videos/` |
| Annotated video | `static/results/videos/` |

---

## 🔒 Security

- Passwords hashed with Flask-Bcrypt
- Session-based authentication (Flask sessions)
- File extension validation on all uploads
- Max upload size: 200 MB
