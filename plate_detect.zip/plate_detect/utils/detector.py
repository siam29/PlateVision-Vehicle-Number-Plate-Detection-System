"""
detector.py — Number plate detection using OpenCV.
Draws a clean GREEN RECTANGLE around each detected plate.
No text is written on or near the plate box.
"""
import cv2
import numpy as np
import os

# ── Load both available Haar cascades ────────────────────────────────────────
_DATA = cv2.data.haarcascades
CASCADE1 = cv2.CascadeClassifier(_DATA + 'haarcascade_russian_plate_number.xml')
CASCADE2 = cv2.CascadeClassifier(_DATA + 'haarcascade_license_plate_rus_16stages.xml')

# Visual style
GREEN      = (0, 210, 60)    # BGR
THICKNESS  = 3


# ── Core helpers ─────────────────────────────────────────────────────────────
def _iou(a, b):
    """Intersection-over-Union of two (x,y,w,h) boxes."""
    ax1, ay1, ax2, ay2 = a[0], a[1], a[0]+a[2], a[1]+a[3]
    bx1, by1, bx2, by2 = b[0], b[1], b[0]+b[2], b[1]+b[3]
    ix = max(0, min(ax2, bx2) - max(ax1, bx1))
    iy = max(0, min(ay2, by2) - max(ay1, by1))
    inter = ix * iy
    union = a[2]*a[3] + b[2]*b[3] - inter
    return inter / union if union > 0 else 0


def _nms(boxes, iou_thresh=0.35):
    """Simple greedy NMS — keeps larger boxes when overlap is high."""
    if not boxes:
        return []
    boxes = sorted(boxes, key=lambda b: b[2]*b[3], reverse=True)
    kept  = []
    used  = [False] * len(boxes)
    for i, box in enumerate(boxes):
        if used[i]:
            continue
        kept.append(box)
        for j in range(i+1, len(boxes)):
            if not used[j] and _iou(box, boxes[j]) > iou_thresh:
                used[j] = True
    return kept


def _cascade_detect(gray, cascade, scale, neighbors, min_size):
    result = cascade.detectMultiScale(
        gray,
        scaleFactor  = scale,
        minNeighbors = neighbors,
        minSize      = min_size,
        flags        = cv2.CASCADE_SCALE_IMAGE,
    )
    return [tuple(r) for r in result] if len(result) > 0 else []


def _contour_candidates(gray, frame_h, frame_w):
    """
    Edge + morphology fallback to catch plates the Haar cascades miss.
    Returns list of (x, y, w, h) candidates with plate-like aspect ratio.
    """
    blurred = cv2.bilateralFilter(gray, 11, 17, 17)
    edges   = cv2.Canny(blurred, 30, 200)

    kernel  = cv2.getStructuringElement(cv2.MORPH_RECT, (17, 3))
    closed  = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    candidates = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        if w < 60 or h < 15:
            continue
        ratio = w / h
        # Typical number-plate aspect: 2 – 6
        if 1.8 <= ratio <= 6.5:
            # Not too large (> 60 % of frame) and not tiny (< 0.1 %)
            area_frac = (w * h) / (frame_w * frame_h)
            if 0.001 <= area_frac <= 0.25:
                candidates.append((x, y, w, h))
    return candidates


def detect_in_frame(frame):
    """
    Detect number plates in a single BGR frame.
    Returns (annotated_frame, plate_count).
    Green rectangle drawn around each unique plate — no text on the box.
    """
    h, w = frame.shape[:2]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)

    # ── 1. Haar cascades ────────────────────────────────────────────────────
    boxes = []
    boxes += _cascade_detect(gray, CASCADE1, scale=1.08, neighbors=5,
                              min_size=(50, 15))
    boxes += _cascade_detect(gray, CASCADE2, scale=1.05, neighbors=3,
                              min_size=(50, 15))

    # ── 2. Contour fallback (only if cascades found nothing) ────────────────
    if not boxes:
        boxes += _contour_candidates(gray, h, w)

    # ── 3. NMS deduplication ─────────────────────────────────────────────────
    unique = _nms(boxes, iou_thresh=0.35)

    # ── 4. Draw clean green rectangles ───────────────────────────────────────
    out = frame.copy()
    for (x, y, bw, bh) in unique:
        # Subtle outer glow (semi-transparent lighter green)
        overlay = out.copy()
        cv2.rectangle(overlay,
                      (x - 3, y - 3), (x + bw + 3, y + bh + 3),
                      (80, 255, 120), 1)
        cv2.addWeighted(overlay, 0.5, out, 0.5, 0, out)
        # Solid main border
        cv2.rectangle(out, (x, y), (x + bw, y + bh), GREEN, THICKNESS)

    return out, len(unique)


# ── Public API ────────────────────────────────────────────────────────────────
def detect_plates_image(input_path: str, output_path: str) -> int:
    """
    Read image → detect plates → save annotated image to output_path.
    Returns number of plates detected.
    """
    frame = cv2.imread(input_path)
    if frame is None:
        return 0

    annotated, count = detect_in_frame(frame)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    cv2.imwrite(output_path, annotated)
    return count
