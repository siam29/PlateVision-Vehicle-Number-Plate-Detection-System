import os
import uuid
from functools import wraps
from flask import (Flask, render_template, request, redirect,
                   url_for, session, jsonify)
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from utils.detector import detect_plates_image

# ── App setup ────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = 'platevision-secret-2024'

BASE = os.path.dirname(os.path.abspath(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.join(BASE, "instance", "users.db")}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024   # 50 MB

UPLOAD_DIR  = os.path.join(BASE, 'static', 'uploads', 'images')
RESULT_DIR  = os.path.join(BASE, 'static', 'results', 'images')
ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'bmp', 'webp'}

os.makedirs(UPLOAD_DIR,  exist_ok=True)
os.makedirs(RESULT_DIR,  exist_ok=True)
os.makedirs(os.path.join(BASE, 'instance'), exist_ok=True)

db     = SQLAlchemy(app)
bcrypt = Bcrypt(app)


# ── Models ───────────────────────────────────────────────────────────────────
class User(db.Model):
    id       = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80),  unique=True, nullable=False)
    email    = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    detections = db.relationship('Detection', backref='user', lazy=True)


class Detection(db.Model):
    id              = db.Column(db.Integer, primary_key=True)
    user_id         = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    orig_name       = db.Column(db.String(200), nullable=False)
    stored_name     = db.Column(db.String(200), nullable=False)
    result_name     = db.Column(db.String(200), nullable=False)
    plates_detected = db.Column(db.Integer, default=0)
    timestamp       = db.Column(db.DateTime, default=db.func.now())


with app.app_context():
    db.create_all()


# ── Helpers ──────────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def allowed(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT


# ── Routes ───────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return redirect(url_for('dashboard') if 'user_id' in session else url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data       = request.get_json()
        identifier = data.get('identifier', '').strip()
        password   = data.get('password', '')
        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier)
        ).first()
        if user and bcrypt.check_password_hash(user.password, password):
            session['user_id']  = user.id
            session['username'] = user.username
            return jsonify({'success': True})
        return jsonify({'success': False, 'message': 'Invalid username/email or password.'})
    return render_template('auth.html', mode='login')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        data     = request.get_json()
        username = data.get('username', '').strip()
        email    = data.get('email', '').strip()
        password = data.get('password', '')

        if not username or not email or not password:
            return jsonify({'success': False, 'message': 'All fields are required.'})
        if len(password) < 6:
            return jsonify({'success': False, 'message': 'Password must be at least 6 characters.'})
        if User.query.filter_by(username=username).first():
            return jsonify({'success': False, 'message': 'Username already taken.'})
        if User.query.filter_by(email=email).first():
            return jsonify({'success': False, 'message': 'Email already registered.'})

        hashed = bcrypt.generate_password_hash(password).decode('utf-8')
        db.session.add(User(username=username, email=email, password=hashed))
        db.session.commit()
        return jsonify({'success': True, 'message': 'Account created! You can now log in.'})
    return render_template('auth.html', mode='signup')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    return render_template('dashboard.html', user=user)


@app.route('/detect', methods=['POST'])
@login_required
def detect():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file received.'})

    f = request.files['file']
    if not f or not f.filename or not allowed(f.filename):
        return jsonify({'success': False, 'message': 'Unsupported file. Use JPG, PNG, WEBP or BMP.'})

    orig_name   = f.filename
    ext         = orig_name.rsplit('.', 1)[1].lower()
    stored_name = f'{uuid.uuid4().hex}.{ext}'
    result_name = f'result_{stored_name}'

    upload_path = os.path.join(UPLOAD_DIR, stored_name)
    result_path = os.path.join(RESULT_DIR, result_name)
    f.save(upload_path)

    count = detect_plates_image(upload_path, result_path)

    det = Detection(
        user_id         = session['user_id'],
        orig_name       = orig_name,
        stored_name     = stored_name,
        result_name     = result_name,
        plates_detected = count,
    )
    db.session.add(det)
    db.session.commit()

    return jsonify({
        'success'     : True,
        'plates'      : count,
        'result_url'  : url_for('static', filename=f'results/images/{result_name}'),
        'orig_url'    : url_for('static', filename=f'uploads/images/{stored_name}'),
        'det_id'      : det.id,
        'orig_name'   : orig_name,
    })


@app.route('/api/history')
@login_required
def api_history():
    rows = (Detection.query
            .filter_by(user_id=session['user_id'])
            .order_by(Detection.timestamp.desc())
            .all())
    return jsonify([{
        'id'      : d.id,
        'name'    : d.orig_name,
        'plates'  : d.plates_detected,
        'result'  : url_for('static', filename=f'results/images/{d.result_name}'),
        'original': url_for('static', filename=f'uploads/images/{d.stored_name}'),
        'time'    : d.timestamp.strftime('%d %b %Y, %H:%M'),
    } for d in rows])


@app.route('/api/stats')
@login_required
def api_stats():
    rows         = Detection.query.filter_by(user_id=session['user_id']).all()
    total_scans  = len(rows)
    total_plates = sum(r.plates_detected for r in rows)
    most_plates  = max((r.plates_detected for r in rows), default=0)
    avg_plates   = round(total_plates / total_scans, 2) if total_scans else 0
    dist          = {}
    for r in rows:
        k = str(r.plates_detected)
        dist[k] = dist.get(k, 0) + 1
    return jsonify({
        'total_scans' : total_scans,
        'total_plates': total_plates,
        'most_plates' : most_plates,
        'avg_plates'  : avg_plates,
        'distribution': dist,
    })


@app.route('/api/delete/<int:det_id>', methods=['DELETE'])
@login_required
def delete_detection(det_id):
    det = Detection.query.filter_by(id=det_id, user_id=session['user_id']).first()
    if not det:
        return jsonify({'success': False, 'message': 'Not found.'})
    for path in [os.path.join(UPLOAD_DIR, det.stored_name),
                 os.path.join(RESULT_DIR,  det.result_name)]:
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
    db.session.delete(det)
    db.session.commit()
    return jsonify({'success': True})


if __name__ == '__main__':
    app.run(debug=True, port=5000)
